import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Search, Menu, X } from 'lucide-react';
import { NAV_ITEMS } from '../../constants';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  return (
    <>
      <nav 
        className={`fixed w-full z-50 transition-all duration-500 ${
          isScrolled || isMobileMenuOpen ? 'bg-secondary/95 backdrop-blur-md py-4 shadow-sm' : 'bg-transparent py-6'
        }`}
      >
        <div className="max-w-[1440px] mx-auto px-6 md:px-12 flex justify-between items-center">
          
          {/* Desktop Nav Left */}
          <div className="hidden md:flex space-x-8">
            {NAV_ITEMS.slice(0, 2).map((item) => (
              <Link 
                key={item.label} 
                to={item.path}
                className="text-xs tracking-[0.2em] font-sans hover:text-accent transition-colors uppercase"
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* Logo */}
          <Link to="/" className="text-3xl md:text-4xl font-serif tracking-tighter text-center absolute left-1/2 transform -translate-x-1/2 z-20 hover:opacity-80 transition-opacity">
            L'ESSENCE
          </Link>

          {/* Desktop Nav Right */}
          <div className="hidden md:flex items-center space-x-8">
            {NAV_ITEMS.slice(2).map((item) => (
              <Link 
                key={item.label} 
                to={item.path}
                className="text-xs tracking-[0.2em] font-sans hover:text-accent transition-colors uppercase"
              >
                {item.label}
              </Link>
            ))}
            <div className="flex items-center space-x-6 border-l border-gray-300 pl-6 ml-4">
              <button className="hover:text-accent transition-colors">
                <Search size={18} strokeWidth={1} />
              </button>
              <Link to="/cart" className="hover:text-accent transition-colors">
                <ShoppingBag size={18} strokeWidth={1} />
              </Link>
            </div>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="flex md:hidden items-center space-x-4">
            <Link to="/cart">
              <ShoppingBag size={20} strokeWidth={1} />
            </Link>
            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
              {isMobileMenuOpen ? <X size={24} strokeWidth={1} /> : <Menu size={24} strokeWidth={1} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div 
        className={`fixed inset-0 bg-secondary z-40 transform transition-transform duration-500 ease-in-out ${
          isMobileMenuOpen ? 'translate-y-0' : '-translate-y-full'
        } pt-32 px-6 md:hidden flex flex-col items-center space-y-8`}
      >
        {NAV_ITEMS.map((item) => (
          <Link 
            key={item.label} 
            to={item.path}
            className="text-2xl font-serif italic tracking-wide hover:text-accent"
          >
            {item.label}
          </Link>
        ))}
        <div className="pt-12 border-t border-gray-200 w-full flex justify-center space-x-8">
          <Link to="/contact" className="text-sm tracking-widest uppercase hover:text-accent">Contact</Link>
          <Link to="/account" className="text-sm tracking-widest uppercase hover:text-accent">Account</Link>
        </div>
      </div>
    </>
  );
};