import React from 'react';
import { Link } from 'react-router-dom';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-secondary pt-24 pb-12 px-6 md:px-12 border-t border-gray-200">
      <div className="max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
          <div className="col-span-1 md:col-span-1">
            <h3 className="font-serif text-2xl mb-6">L'ESSENCE</h3>
            <p className="font-sans text-xs tracking-wide leading-relaxed text-gray-600">
              Biotech ingredients. <br/>
              Master perfumery.<br/>
              Natural processes.<br/>
              Radical transparency.
            </p>
          </div>
          
          <div className="col-span-1">
            <h4 className="font-inter font-medium tracking-[-1.25px] leading-none uppercase text-sm mb-6">Shop</h4>
            <ul className="space-y-3">
              <li><Link to="/shop" className="font-serif text-lg italic text-gray-600 hover:text-accent transition-colors">All Fragrances</Link></li>
              <li><Link to="/shop" className="font-serif text-lg italic text-gray-600 hover:text-accent transition-colors">Discovery Sets</Link></li>
              <li><Link to="/shop" className="font-serif text-lg italic text-gray-600 hover:text-accent transition-colors">Room Sprays</Link></li>
            </ul>
          </div>

          <div className="col-span-1">
            <h4 className="font-inter font-medium tracking-[-1.25px] leading-none uppercase text-sm mb-6">About</h4>
            <ul className="space-y-3">
              <li><Link to="/story" className="font-serif text-lg italic text-gray-600 hover:text-accent transition-colors">Our Story</Link></li>
              <li><Link to="/contact" className="font-serif text-lg italic text-gray-600 hover:text-accent transition-colors">Ingredients</Link></li>
              <li><Link to="/contact" className="font-serif text-lg italic text-gray-600 hover:text-accent transition-colors">Sustainability</Link></li>
            </ul>
          </div>

          <div className="col-span-1">
             <h4 className="font-inter font-medium tracking-[-1.25px] leading-none uppercase text-sm mb-6">Newsletter</h4>
             <p className="font-sans text-xs text-gray-500 mb-4">Join our list for early access to new releases.</p>
             <form className="flex border-b border-black pb-2 focus-within:border-accent transition-colors">
               <input 
                 type="email" 
                 placeholder="Email Address" 
                 className="bg-transparent w-full outline-none font-sans text-sm placeholder-gray-400"
               />
               <button type="submit" className="uppercase text-xs tracking-widest hover:text-accent transition-colors">Join</button>
             </form>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-gray-200">
          <p className="font-sans text-[10px] tracking-widest text-gray-400 uppercase">© 2024 L'Essence Parfums</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
             <a href="#" className="font-sans text-[10px] tracking-widest text-gray-400 uppercase hover:text-accent transition-colors">Instagram</a>
             <a href="#" className="font-sans text-[10px] tracking-widest text-gray-400 uppercase hover:text-accent transition-colors">TikTok</a>
             <a href="#" className="font-sans text-[10px] tracking-widest text-gray-400 uppercase hover:text-accent transition-colors">Pinterest</a>
          </div>
        </div>
      </div>
    </footer>
  );
};