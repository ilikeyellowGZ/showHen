import { Product } from './types';

export const NAV_ITEMS = [
  { label: 'Shop', path: '/shop' },
  { label: 'Discovery Sets', path: '/shop' }, // Simplified routing for demo
  { label: 'Our Story', path: '/story' }, // Simplified routing
  { label: 'Journal', path: '/contact' }, // Simplified routing
];

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Green Cedar',
    subtitle: 'A Velvety, Rich Wood',
    price: 145,
    description: 'A unique combination of twice distilled Texas cedar and wild harvested Atlas mountain cedar. A rich and distinctive fragrance that marries the dry woodiness of cedar with the unexpected sweetness of magnolia.',
    notes: ['Magnolia', 'Cardamom', 'Cedarwood', 'Guaiac Wood'],
    image: 'https://picsum.photos/800/1000?random=1',
    secondaryImage: 'https://picsum.photos/800/1000?random=11',
    category: 'parfum',
    isBestSeller: true,
  },
  {
    id: '2',
    name: 'Cyan Nori',
    subtitle: 'A Sweet, Salty Musk',
    price: 145,
    description: 'Inspired by the ocean, Cyan Nori is a modern, salty, and sweet musk. It opens with a burst of tangerine and peach, grounded by the savory depth of nori.',
    notes: ['Tangerine', 'White Peach', 'Nori', 'Musk'],
    image: 'https://picsum.photos/800/1000?random=2',
    secondaryImage: 'https://picsum.photos/800/1000?random=12',
    category: 'parfum',
  },
  {
    id: '3',
    name: 'The Apartment',
    subtitle: 'Dark & Sophisticated Gourmand',
    price: 165,
    description: 'A decadent and complex scent, The Apartment captures the essence of a Parisian evening. Cherry, rum, and cacao create an intoxicating opening that settles into a warm, amber base.',
    notes: ['Sour Cherry', 'Rum', 'Cacao', 'Myrrh'],
    image: 'https://picsum.photos/800/1000?random=3',
    secondaryImage: 'https://picsum.photos/800/1000?random=13',
    category: 'parfum',
    isNew: true,
  },
  {
    id: '4',
    name: 'Cobalt Amber',
    subtitle: 'Classic Oriental',
    price: 145,
    description: 'A sophisticated oriental fragrance that is both comforting and alluring. Pink pepper and juniper berry give way to a heart of cacao and tonka bean.',
    notes: ['Pink Pepper', 'Juniper Berry', 'Cacao', 'Amber'],
    image: 'https://picsum.photos/800/1000?random=4',
    secondaryImage: 'https://picsum.photos/800/1000?random=14',
    category: 'parfum',
  },
  {
    id: '5',
    name: 'Discovery Set',
    subtitle: 'Explore the Collection',
    price: 45,
    description: 'The perfect introduction to L\'Essence. This set contains 2ml samples of our five most beloved fragrances, allowing you to discover your signature scent at your own pace.',
    notes: ['5 x 2ml Vials', 'Organic Cotton Pouch', 'Scent Guide'],
    image: 'https://picsum.photos/800/1000?random=5',
    secondaryImage: 'https://picsum.photos/800/1000?random=15',
    category: 'set',
  },
  {
    id: '6',
    name: 'White Vetiver',
    subtitle: 'Cool & Crisp',
    price: 145,
    description: 'A cool, fresh vetiver that opens with a zesty lime and mint accord. The heart reveals a creamy palmarosa note before settling into the dry, woody base of vetiver.',
    notes: ['Lime', 'Mint', 'Palmarosa', 'Vetiver'],
    image: 'https://picsum.photos/800/1000?random=6',
    secondaryImage: 'https://picsum.photos/800/1000?random=16',
    category: 'parfum',
  },
];
