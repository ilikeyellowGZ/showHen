import React from 'react';
import { ProductCard } from '../components/UI/ProductCard';
import { PRODUCTS } from '../constants';
import { FadeIn } from '../components/UI/FadeIn';

export const Shop: React.FC = () => {
  return (
    <div className="pt-32 pb-24 bg-secondary min-h-screen">
      <div className="max-w-[1440px] mx-auto px-6 md:px-12">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 border-b border-gray-300 pb-8">
          <div>
            <h1 className="font-serif text-5xl md:text-6xl mb-4">All Fragrances</h1>
            <p className="font-sans text-xs tracking-widest text-gray-500 uppercase max-w-md">
              100% Natural. Unisex. Created by Master Perfumers.
            </p>
          </div>
          <div className="flex space-x-6 mt-8 md:mt-0">
             <button className="font-sans text-xs uppercase tracking-widest hover:text-gray-500">Filter</button>
             <button className="font-sans text-xs uppercase tracking-widest hover:text-gray-500">Sort</button>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
          {PRODUCTS.map((product, idx) => (
             <FadeIn key={product.id} delay={idx * 100}>
               <ProductCard product={product} />
             </FadeIn>
          ))}
        </div>

      </div>
    </div>
  );
};